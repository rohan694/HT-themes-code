jQuery(document).ready(function($) {
    //const product_slider = $('#products-slider .products')

    /*product_slider.flexslider({
        animation: "slide",
    })*/

    //$('#related_product_slider').slick();
})