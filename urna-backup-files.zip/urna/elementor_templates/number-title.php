<?php
/**
 * Templates Name: Elementor
 * Widget: Number Title
 */
extract($settings);


?>

<div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>

    <?php $this->get_number_title(); ?>

</div>