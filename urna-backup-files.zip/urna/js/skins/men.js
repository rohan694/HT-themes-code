'use strict';

jQuery(document).ready(() => {
});
