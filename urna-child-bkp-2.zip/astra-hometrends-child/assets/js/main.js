jQuery(document).ready(function ($) {
    $('#related_product_slider').slick({
        arrows: true,
        vertical: false,
        slide: 'li',
        slidesToShow:4,
        slidesToScroll:1,
        adaptiveHeight: true,
        variableWidth: true,
        /*prevArrow: $('.ca_goUp'),
        nextArrow: $('.ca_goDown'),*/
        infinite:false,
    });
})

/*
jQuery(document).ready(function($){
    function start_slick(){
        $('#related_product_slider').slick({
            arrows: false,
            vertical: false,
            slide: 'li',
            slidesToShow:3,
            slidesToScroll:1,
            /!*prevArrow: $('.ca_goUp'),
            nextArrow: $('.ca_goDown'),*!/
            infinite:false,
        });
    }
    window.setTimeout( start_slick, 2000 );
});*/
